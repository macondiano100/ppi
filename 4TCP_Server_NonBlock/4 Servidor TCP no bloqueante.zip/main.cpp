//Estudiante: Vidal Sanchez Jose Antonio
//Practica: 4
//Servidor TCP No bloqueante
#include <stdio.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <netdb.h>
#include <cstdlib>
#include <cstring>
#include <unistd.h>
#include <iostream>
#include <arpa/inet.h>
using namespace std;
int main()
{
    int serverDes,clientDes;
    sockaddr_in infoServer,info_cliente;
    constexpr long port=12345;
    constexpr int TAMANIO_MENSAJE=255;
    char mensaje[TAMANIO_MENSAJE+1]="Yo no sufro\n";
    serverDes=socket(AF_INET,SOCK_STREAM,0);
    if(serverDes<0)
    {
        perror("Error al crear socket");
        exit(1);
    }
    memset(&infoServer,0,sizeof(sockaddr_in));
    int optval=1;
    if (setsockopt(serverDes, SOL_SOCKET, SO_REUSEADDR, &optval, sizeof(optval))<0)//evitar el TIME_WAIT
    {
        perror("setsockopt");
        exit(1);
    }
    infoServer.sin_addr.s_addr=htonl (INADDR_ANY);
    infoServer.sin_port=htons(port);
    infoServer.sin_family=AF_INET;
    long flags;
    flags=fcntl(serverDes,F_GETFL);
    flags=flags|O_NONBLOCK;
    if(fcntl(serverDes,F_SETFL,flags))
    {
        perror("Error al configurar el servidor no bloqueante");
    }
    if(bind(serverDes,(struct sockaddr *)&infoServer,sizeof(infoServer))<0)
    {
        perror("Error al vincular el servidor");
        exit(1);
    }
    listen(serverDes,5);
    socklen_t size_sockaddr=sizeof(sockaddr_in);
    struct timeval tiempoInicio,tiempoActual;
    long tiempoTranscurrido;
    bool continuarServidor;
    cout<<"Esperando conecciones:"<<endl;
    gettimeofday(&tiempoInicio,nullptr);
    while(continuarServidor)
    {
        clientDes=accept(serverDes,(struct sockaddr *)&info_cliente,&size_sockaddr);
        if(clientDes<0)
        {
            gettimeofday(&tiempoActual,nullptr);
            tiempoTranscurrido=
                (tiempoActual.tv_sec - tiempoInicio.tv_sec) * 1000 + (tiempoActual.tv_usec - tiempoInicio.tv_usec)/1000;
            if(tiempoTranscurrido>1000)
            {
                cout<<".";
                cout.flush();
                gettimeofday(&tiempoInicio,nullptr);
            }
        }
        else
        {
            cout<<endl<<"Conección entrante de "<<inet_ntoa(info_cliente.sin_addr)
                <<" con puerto: "<<ntohs(info_cliente.sin_port)<<endl;
            write(clientDes,mensaje,TAMANIO_MENSAJE);
            gettimeofday(&tiempoInicio,nullptr);
            if(close(clientDes)<0)
            {
                cout<<"Error al cerrar el cliente";
                exit(1);
            }
            cout<<"-->Presione 'x' para cerrar el servidor."<<endl;
            cout<<"   Cualquier otra tecla para esperar más conecciones:";
            if(::tolower(cin.get())=='x') continuarServidor=false;
        }
    }

    if(close(serverDes)<0)
    {
        cout<<"Error al cerrar el servidor";
        exit(1);
    }
    return 0;
}
